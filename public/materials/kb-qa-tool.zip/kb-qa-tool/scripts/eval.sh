#!/usr/bin/env bash
# 通用 CI 脚本（不依赖 GitHub Actions，任何流水线或本地均可执行）
# 用法：bash scripts/eval.sh [阈值]
set -e
cd "$(dirname "$0")/.."
python -m pytest tests/ -q
python -m kbqa index sample_docs --db kb_index.json
python -m kbqa eval evalset/sample_evalset.jsonl --db kb_index.json --threshold "${1:-0.55}" --out eval_report.json
