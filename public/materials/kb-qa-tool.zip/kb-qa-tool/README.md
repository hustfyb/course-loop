# 知识库问答工具（课程实验 3–4 载体）

《软件工程 3.0》第 5–6 周语境载体。一个「产品化」的 RAG 问答 CLI：索引任意 markdown 目录并回答提问。**纯标准库实现、离线可跑**；设置环境变量后切换为真实 LLM。

## 快速开始（30 秒）

```bash
cd kb-qa-tool
python -m kbqa index sample_docs                 # 构建索引
python -m kbqa ask "一线城市住宿标准是多少？"      # 离线抽取式回答
python -m kbqa eval evalset/sample_evalset.jsonl # 跑示例评测集
bash scripts/eval.sh                             # 完整回归：单测 + 评估（CI 同款）
```

## 切换真实 LLM（可选）

```bash
export KBQA_API_KEY=sk-...                       # 生成模型（OpenAI 兼容接口）
export KBQA_BASE_URL=https://api.moonshot.cn/v1  # 默认值，可换任何兼容端点
export KBQA_MODEL=kimi-k2.6
export KBQA_JUDGE_API_KEY=sk-...                 # LLM-as-Judge（可用更便宜的模型）
python -m kbqa eval evalset/sample_evalset.jsonl --judge
```

## 设计要点（教学锚点）

- `retriever.py`：按标题切分 + TF-IDF 检索——W3 手写 RAG 的产品化形态
- `generator.py`：检索分低于阈值即拒答（无答案问题的第一道防线）；LLM 模式强制「只许根据资料回答」
- `evaluator.py`：规则评分（关键词命中 / 拒答检测）+ 可选 LLM-as-Judge（先理由后分数）；总分低于阈值退出码为 1——**这就是 CI 红灯的机制**
- `evalset/sample_evalset.jsonl`：22 条示例用例，事实 / 多文档综合 / 无答案三类齐备
- **实验 3**：以此工具为对象建你们自己的评测集（≥20 条）、双轨 scorer、CI 红灯
- **实验 4**：互攻他组副本——试试往 sample_docs 里塞一份带毒文档（见 `../security-samples/`）
