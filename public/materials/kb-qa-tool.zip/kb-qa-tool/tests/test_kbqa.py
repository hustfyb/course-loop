# -*- coding: utf-8 -*-
"""脚手架自检：检索、拒答、规则评分。教师课前验收用。"""
import os, tempfile
from kbqa.retriever import TfidfIndex, load_corpus
from kbqa.generator import answer, REFUSAL
from kbqa.evaluator import rule_score

DOCS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "sample_docs")


def _index():
    idx = TfidfIndex()
    idx.build(load_corpus(DOCS))
    return idx


def test_retrieval_hits():
    idx = _index()
    res = idx.search("报销住宿标准是多少")
    assert res and "报销" in res[0]["doc"]


def test_refusal_on_unknown():
    idx = _index()
    ans = answer("公司的下午茶补贴是多少钱？", idx.search("公司的下午茶补贴是多少钱？"))
    assert REFUSAL in ans


def test_rule_scorer():
    assert rule_score({"type": "factoid", "expect": ["500"]}, "一线城市每晚不超过 500 元") == 1.0
    assert rule_score({"type": "noanswer", "expect": []}, REFUSAL) == 1.0
    assert rule_score({"type": "noanswer", "expect": []}, "补贴 50 元") == 0.0


def test_index_roundtrip():
    idx = _index()
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "i.json")
        idx.save(p)
        loaded = TfidfIndex.load(p)
        assert loaded.search("远程办公")[0]["doc"] == idx.search("远程办公")[0]["doc"]
