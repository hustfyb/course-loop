# -*- coding: utf-8 -*-
"""评估器：规则评分 + 可选 LLM-as-Judge；分数低于阈值时退出码为 1（供 CI 拦截）。"""
import json, os, re, urllib.request

from .generator import REFUSAL


def _norm(s):
    return re.sub(r"\s+", "", s).lower()


def rule_score(case, answer):
    """事实/综合题：期望关键词须出现在回答中；无答案题：必须拒答。"""
    if case["type"] == "noanswer":
        return 1.0 if REFUSAL in answer else 0.0
    expects = case["expect"] if isinstance(case["expect"], list) else [case["expect"]]
    hit = sum(1 for e in expects if _norm(e) in _norm(answer))
    return hit / len(expects)


JUDGE_PROMPT = """你是严格的评审。根据评分标准给回答打分。

[问题]
{question}

[参考答案要点]
{expect}

[被评回答]
{answer}

[评分标准]
1. 正确性：与参考要点一致，无编造
2. 完整性：覆盖全部要点
3. 有据：结论来自资料而非臆测

先逐条给出理由，最后一行只输出 JSON：{{"score": 0 到 1 之间的小数}}"""


def judge_score(case, answer):
    """LLM-as-Judge。仅在设置 KBQA_JUDGE_API_KEY 时启用。"""
    api_key = os.environ.get("KBQA_JUDGE_API_KEY")
    base = os.environ.get("KBQA_JUDGE_BASE_URL", "https://api.moonshot.cn/v1")
    model = os.environ.get("KBQA_JUDGE_MODEL", "kimi-k2.6")
    prompt = JUDGE_PROMPT.format(question=case["question"], expect=case["expect"], answer=answer)
    req = urllib.request.Request(
        base.rstrip("/") + "/chat/completions",
        data=json.dumps({"model": model, "messages": [{"role": "user", "content": prompt}],
                         "temperature": 0}).encode(),
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"})
    with urllib.request.urlopen(req, timeout=60) as resp:
        text = json.load(resp)["choices"][0]["message"]["content"]
    m = re.search(r'"score"\s*:\s*([0-9.]+)', text)
    return float(m.group(1)) if m else 0.0


def evaluate(cases, answer_fn, use_judge=False, threshold=0.8, out=None):
    """answer_fn(question) -> answer。返回 (score, results)。"""
    results = []
    for case in cases:
        ans = answer_fn(case["question"])
        rule = rule_score(case, ans)
        score = rule
        judged = None
        if use_judge and case["type"] != "noanswer":
            judged = judge_score(case, ans)
            score = (rule + judged) / 2
        results.append({"id": case["id"], "type": case["type"], "question": case["question"],
                        "answer": ans, "rule": rule, "judge": judged, "score": round(score, 3)})
    overall = round(sum(r["score"] for r in results) / len(results), 3) if results else 0.0
    summary = {"overall": overall, "threshold": threshold, "passed": overall >= threshold,
               "n": len(results),
               "by_type": {}}
    for r in results:
        t = summary["by_type"].setdefault(r["type"], [])
        t.append(r["score"])
    for t, v in summary["by_type"].items():
        summary["by_type"][t] = round(sum(v) / len(v), 3)
    if out:
        with open(out, "w", encoding="utf-8") as f:
            json.dump({"summary": summary, "results": results}, f, ensure_ascii=False, indent=2)
    return overall, summary, results
