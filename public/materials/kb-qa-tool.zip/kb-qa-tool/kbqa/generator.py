# -*- coding: utf-8 -*-
"""生成器：默认离线抽取式回答；设置环境变量后切换为 LLM 生成。

LLM 模式（OpenAI 兼容接口）：
  KBQA_API_KEY / KBQA_BASE_URL（默认 https://api.moonshot.cn/v1）/ KBQA_MODEL
"""
import json, os, urllib.request

REFUSAL = "知识库中没有相关信息，无法回答该问题。"
RETRIEVAL_THRESHOLD = 0.20  # 检索最高分低于此值视为「无答案」；之上仍需内容词重叠校验

_STOP = set("的了是吗呢吧多少怎么什么怎样请问我你他她它们在")


def _bigrams(text):
    chars = [c for c in text if "一" <= c <= "鿿"]
    return {a + b for a, b in zip(chars, chars[1:]) if a not in _STOP and b not in _STOP}


def _has_content_overlap(question, chunk_text):
    """查询与最佳片段必须有中文二字组重叠，否则视为检索噪声（无答案）。
    教学点：固定阈值挡不住「字面上有点像」的噪声命中。"""
    return bool(_bigrams(question) & _bigrams(chunk_text))


def _extractive(question, chunks):
    """离线兜底：取最高分 chunk 的前两句作为回答，并标注出处。"""
    if not chunks or chunks[0]["score"] < RETRIEVAL_THRESHOLD \
            or not _has_content_overlap(question, chunks[0]["text"]):
        return REFUSAL
    top = chunks[0]
    sentences = [s for s in top["text"].replace("\n", " ").split("。") if s.strip()]
    body = "。".join(sentences[:2]) + "。"
    cites = "；".join(f"{c['doc']}#{c['heading']}" for c in chunks[:2])
    return f"{body}（来源：{cites}）"


def _llm(question, chunks):
    api_key = os.environ.get("KBQA_API_KEY")
    base = os.environ.get("KBQA_BASE_URL", "https://api.moonshot.cn/v1")
    model = os.environ.get("KBQA_MODEL", "kimi-k2.6")
    context = "\n\n".join(f"[{c['doc']}#{c['heading']}]\n{c['text']}" for c in chunks)
    prompt = (
        "你是知识库问答助手。只允许根据给定资料回答；资料不足以回答时必须回答："
        f"「{REFUSAL}」。回答末尾标注来源（文档名#小节）。\n\n资料：\n{context}\n\n问题：{question}"
    )
    req = urllib.request.Request(
        base.rstrip("/") + "/chat/completions",
        data=json.dumps({"model": model,
                         "messages": [{"role": "user", "content": prompt}],
                         "temperature": 0.2}).encode(),
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"})
    with urllib.request.urlopen(req, timeout=60) as resp:
        return json.load(resp)["choices"][0]["message"]["content"]


def answer(question, chunks):
    if os.environ.get("KBQA_API_KEY"):
        return _llm(question, chunks)
    return _extractive(question, chunks)
