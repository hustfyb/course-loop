# -*- coding: utf-8 -*-
"""检索器：按标题切分 markdown + TF-IDF 检索。纯标准库实现，保证离线可跑。

教学说明：这是实验 3–4 的载体。它把 W3 手写的 RAG「产品化」——
学生本周的任务不是重写检索，而是为整个问答系统建评估与安全防线。
"""
import json, math, os, re
from collections import Counter

_TOKEN_RE = re.compile(r"[A-Za-z0-9_]+|[一-鿿]")


def tokenize(text):
    """中英混合的最小分词：英文按词、中文按字（够用且零依赖）。"""
    return _TOKEN_RE.findall(text.lower())


def chunk_markdown(path):
    """按二级以上标题切分 markdown，返回 [{doc, heading, text}]。"""
    doc = os.path.basename(path)
    with open(path, encoding="utf-8") as f:
        lines = f.read().split("\n")
    chunks, heading, buf = [], "（开头）", []
    for ln in lines:
        m = re.match(r"^(#{1,3})\s+(.*)", ln)
        if m:
            if buf:
                chunks.append({"doc": doc, "heading": heading, "text": "\n".join(buf).strip()})
            heading, buf = m.group(2).strip(), []
        else:
            buf.append(ln)
    if buf:
        chunks.append({"doc": doc, "heading": heading, "text": "\n".join(buf).strip()})
    return [c for c in chunks if c["text"]]


def load_corpus(directory):
    chunks = []
    for fn in sorted(os.listdir(directory)):
        if fn.endswith(".md"):
            chunks.extend(chunk_markdown(os.path.join(directory, fn)))
    return chunks


class TfidfIndex:
    def __init__(self):
        self.chunks = []
        self.idf = {}
        self.tfidf = []

    def build(self, chunks):
        self.chunks = chunks
        docs = [tokenize(c["heading"] + " " + c["text"]) for c in chunks]
        df = Counter()
        for toks in docs:
            for t in set(toks):
                df[t] += 1
        n = len(docs)
        self.idf = {t: math.log((n + 1) / (c + 1)) + 1 for t, c in df.items()}
        self.tfidf = []
        for toks in docs:
            tf = Counter(toks)
            vec = {t: (cnt / len(toks)) * self.idf.get(t, 0) for t, cnt in tf.items()} if toks else {}
            self.tfidf.append(vec)

    @staticmethod
    def _cosine(a, b):
        common = set(a) & set(b)
        dot = sum(a[t] * b[t] for t in common)
        na = math.sqrt(sum(v * v for v in a.values()))
        nb = math.sqrt(sum(v * v for v in b.values()))
        return dot / (na * nb) if na and nb else 0.0

    def search(self, query, k=3):
        toks = tokenize(query)
        tf = Counter(toks)
        qvec = {t: (cnt / len(toks)) * self.idf.get(t, 0) for t, cnt in tf.items()} if toks else {}
        scored = [(self._cosine(qvec, vec), i) for i, vec in enumerate(self.tfidf)]
        scored.sort(reverse=True)
        return [{"score": round(s, 4), **self.chunks[i]} for s, i in scored[:k] if s > 0]

    def save(self, path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"chunks": self.chunks, "idf": self.idf, "tfidf": self.tfidf}, f,
                      ensure_ascii=False)

    @classmethod
    def load(cls, path):
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        idx = cls()
        idx.chunks, idx.idf, idx.tfidf = data["chunks"], data["idf"], data["tfidf"]
        return idx
