# -*- coding: utf-8 -*-
"""命令行入口：
  python -m kbqa index <文档目录> [--db kb_index.json]
  python -m kbqa ask "问题" [--db kb_index.json]
  python -m kbqa eval <评测集.jsonl> [--db kb_index.json] [--judge] [--threshold 0.8] [--out report.json]
"""
import argparse, json, sys

from .retriever import TfidfIndex, load_corpus
from .generator import answer
from .evaluator import evaluate


def main(argv=None):
    p = argparse.ArgumentParser(prog="kbqa", description="知识库问答工具（课程实验 3–4 载体）")
    sub = p.add_subparsers(dest="cmd", required=True)

    pi = sub.add_parser("index", help="索引一个 markdown 目录")
    pi.add_argument("docs")
    pi.add_argument("--db", default="kb_index.json")

    pa = sub.add_parser("ask", help="提问")
    pa.add_argument("question")
    pa.add_argument("--db", default="kb_index.json")
    pa.add_argument("-k", type=int, default=3)

    pe = sub.add_parser("eval", help="运行评测集")
    pe.add_argument("evalset")
    pe.add_argument("--db", default="kb_index.json")
    pe.add_argument("--judge", action="store_true", help="启用 LLM-as-Judge（需 KBQA_JUDGE_API_KEY）")
    pe.add_argument("--threshold", type=float, default=0.8)
    pe.add_argument("--out", default=None)

    args = p.parse_args(argv)

    if args.cmd == "index":
        chunks = load_corpus(args.docs)
        idx = TfidfIndex()
        idx.build(chunks)
        idx.save(args.db)
        print(f"已索引 {len(chunks)} 个片段 → {args.db}")
        return 0

    idx = TfidfIndex.load(args.db)

    if args.cmd == "ask":
        chunks = idx.search(args.question, k=args.k)
        print(answer(args.question, chunks))
        return 0

    if args.cmd == "eval":
        with open(args.evalset, encoding="utf-8") as f:
            cases = [json.loads(ln) for ln in f if ln.strip()]

        def answer_fn(q):
            return answer(q, idx.search(q, k=3))

        overall, summary, _ = evaluate(cases, answer_fn, use_judge=args.judge,
                                       threshold=args.threshold, out=args.out)
        print(f"用例数: {summary['n']}  总分: {overall}  阈值: {args.threshold}")
        for t, v in summary["by_type"].items():
            print(f"  {t}: {v}")
        if not summary["passed"]:
            print("评估未通过（红灯）", file=sys.stderr)
            return 1
        print("评估通过（绿灯）")
        return 0


if __name__ == "__main__":
    sys.exit(main())
