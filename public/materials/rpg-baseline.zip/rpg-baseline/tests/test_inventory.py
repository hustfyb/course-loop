# -*- coding: utf-8 -*-
"""既有测试：实验 1 的验收要求之一是这些测试保持通过。"""
import pytest
from rpg.item import Item
from rpg.inventory import Inventory


def test_add_and_count():
    inv = Inventory()
    inv.add(Item("铁剑", "common", attack=5))
    assert inv.count() == 1


def test_capacity_limit():
    inv = Inventory(capacity=1)
    inv.add(Item("铁剑", "common"))
    with pytest.raises(ValueError):
        inv.add(Item("盾牌", "common"))


def test_remove():
    inv = Inventory()
    inv.add(Item("铁剑", "common"))
    inv.remove("铁剑")
    assert inv.count() == 0
    with pytest.raises(KeyError):
        inv.remove("不存在的物品")


def test_rarity_validation():
    with pytest.raises(ValueError):
        Item("假装备", "legendary-plus")
