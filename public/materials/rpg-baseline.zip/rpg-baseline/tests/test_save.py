# -*- coding: utf-8 -*-
import json, os, tempfile
from rpg.item import Item
from rpg.inventory import Inventory
from rpg.save import save_game, load_game


def test_save_load_roundtrip():
    inv = Inventory()
    inv.add(Item("龙息法杖", "epic", attack=30))
    inv.add(Item("治疗药水", "common", heal=20))
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "save.json")
        save_game(inv, p)
        loaded = load_game(p)
    assert loaded.count() == 2
    assert loaded.items[0].name == "龙息法杖"
    assert loaded.items[1].heal == 20
