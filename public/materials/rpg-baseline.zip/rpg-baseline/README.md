# 终端 RPG 基线项目（课程素材）

《软件工程 3.0》第 1–4 周统一语境。一个刻意保持极简的终端 RPG，用于承载实验 1（规格驱动开发）与实验 2（RAG + Agent 工具）。

## 一键验证

```bash
cd rpg-baseline
python -m pytest tests/ -q     # 既有测试应全部通过
python -m rpg.game             # 进入游戏：e=探索 i=背包 q=退出
```

## 结构

```
rpg/
  item.py       # Item：name / rarity / attack / defense / heal
  inventory.py  # Inventory + sort_inventory（空实现，实验 1 任务点）
  save.py       # 存档读写（实验 1 约束：不得修改）
  game.py       # 极简终端游戏循环
tests/          # 既有测试：实验 1 不得破坏
```

## 教学锚点

- **实验 1（W2）**：实现 `sort_inventory`（按稀有度降序、同稀有度按名称、不改原列表）；既有测试必须保持通过；`save.py` 与 `Item` 类不得修改
- **实验 2（W3–4）**：以本项目的「设计文档集」（`../rpg-docs/`）为 RAG 语料；为 Agent 增加的 `run_tests` 工具以本项目为验证对象
- 项目刻意不完美：没有异常处理的输入循环、没有排序——这些「缺口」就是实验的任务面
