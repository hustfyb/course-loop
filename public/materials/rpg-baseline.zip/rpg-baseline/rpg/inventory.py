# -*- coding: utf-8 -*-
"""背包系统。实验 1 的任务点：实现 sort_inventory。"""
from .item import Item, RARITY_ORDER


class Inventory:
    def __init__(self, capacity=20):
        self.capacity = capacity
        self.items = []

    def add(self, item):
        if len(self.items) >= self.capacity:
            raise ValueError("背包已满")
        self.items.append(item)

    def remove(self, name):
        for i, it in enumerate(self.items):
            if it.name == name:
                return self.items.pop(i)
        raise KeyError(f"背包中没有物品: {name}")

    def count(self):
        return len(self.items)


def sort_inventory(items):
    """按稀有度排序背包物品。

    要求（实验 1 的 spec 起点，当前为空实现）：
    - 按稀有度降序：legendary > epic > rare > common
    - 同稀有度按名称排序
    - 不修改原列表，返回新列表
    """
    # TODO: 实验 1 由学生（借助 Agent）实现
    raise NotImplementedError("sort_inventory 尚未实现")
