# -*- coding: utf-8 -*-
"""存档读写。实验 1 的约束之一：不得修改本文件。"""
import json
from .item import Item
from .inventory import Inventory


def save_game(inventory, path):
    data = [{"name": it.name, "rarity": it.rarity,
             "attack": it.attack, "defense": it.defense, "heal": it.heal}
            for it in inventory.items]
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"items": data}, f, ensure_ascii=False, indent=2)


def load_game(path):
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    inv = Inventory()
    for d in data.get("items", []):
        inv.add(Item(**d))
    return inv
