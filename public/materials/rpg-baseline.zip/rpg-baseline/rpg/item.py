# -*- coding: utf-8 -*-
"""物品定义。稀有度字段为实验 1 的排序依据。"""
from dataclasses import dataclass

RARITY_ORDER = ["common", "rare", "epic", "legendary"]


@dataclass
class Item:
    name: str
    rarity: str  # common / rare / epic / legendary
    attack: int = 0
    defense: int = 0
    heal: int = 0

    def __post_init__(self):
        if self.rarity not in RARITY_ORDER:
            raise ValueError(f"未知稀有度: {self.rarity}")
