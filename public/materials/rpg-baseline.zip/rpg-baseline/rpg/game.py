# -*- coding: utf-8 -*-
"""极简终端游戏循环：探索 → 拾取 → 查看背包。教学用基线，非完整游戏。"""
from .item import Item
from .inventory import Inventory

LOOT_TABLE = [
    Item("治疗药水", "common", heal=20),
    Item("铁剑", "common", attack=5),
    Item("秘银护甲", "rare", defense=12),
    Item("龙息法杖", "epic", attack=30),
    Item("凤凰之羽", "legendary", heal=100),
]


def explore(inv, step):
    """确定性拾取：按步数取战利品，便于课堂演示与测试。"""
    item = LOOT_TABLE[step % len(LOOT_TABLE)]
    inv.add(item)
    return item


def render_inventory(inv):
    lines = ["背包（{} / {}）".format(inv.count(), inv.capacity)]
    for it in inv.items:
        lines.append(f"- [{it.rarity}] {it.name} 攻{it.attack} 防{it.defense} 疗{it.heal}")
    return "\n".join(lines)


def main():
    inv = Inventory()
    step = 0
    print("终端 RPG 基线版。命令：e=探索 i=背包 q=退出")
    while True:
        cmd = input("> ").strip().lower()
        if cmd == "q":
            break
        if cmd == "e":
            item = explore(inv, step)
            step += 1
            print(f"拾取：{item.name}（{item.rarity}）")
        elif cmd == "i":
            print(render_inventory(inv))
        else:
            print("未知命令")


if __name__ == "__main__":
    main()
