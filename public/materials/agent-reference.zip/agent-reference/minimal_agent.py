# -*- coding: utf-8 -*-
"""最小 Agent 参考实现（约 60 行）：W2 讲授演示 + W4 实验的对照基线。

构成公式对照（课堂逐行讲）：
  大模型   = chat()            —— 思考
  工具     = TOOLS + run_tool  —— 手脚
  记忆     = messages          —— 对话上下文
  控制循环 = agent_loop        —— 行动 → 观察 → 再行动

运行：export KBQA_API_KEY=sk-...（或任何 OpenAI 兼容端点）
     python minimal_agent.py "修复 sample_project 里失败的测试"
"""
import json, os, subprocess, sys, urllib.request

BASE = os.environ.get("KBQA_BASE_URL", "https://api.moonshot.cn/v1")
MODEL = os.environ.get("KBQA_MODEL", "kimi-k2.6")
KEY = os.environ.get("KBQA_API_KEY", "")

SYSTEM = "你是编程智能体。用工具完成任务：先读文件理解问题，修改后运行测试验证。文件操作仅限当前目录。"

TOOLS = [
    {"name": "read_file", "description": "读取文件内容。需要了解代码或报错时调用",
     "params": ["path"]},
    {"name": "write_file", "description": "覆盖写入文件。修改代码时调用",
     "params": ["path", "content"]},
    {"name": "run_tests", "description": "运行 pytest 并返回通过率与失败摘要。修改代码后必须调用以验证",
     "params": []},
]


def chat(messages):
    """调用模型；要求模型用 JSON 行动指令回复：{"tool": ..., "args": {...}} 或 {"done": "总结"}"""
    prompt = messages[-1]["content"] + "\n\n可用工具：" + json.dumps(
        TOOLS, ensure_ascii=False) + "\n只输出一个 JSON 对象，不要输出其他内容。"
    req = urllib.request.Request(
        BASE.rstrip("/") + "/chat/completions",
        data=json.dumps({"model": MODEL, "messages": messages[:-1] + [
            {"role": "user", "content": prompt}], "temperature": 0}).encode(),
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {KEY}"})
    with urllib.request.urlopen(req, timeout=120) as resp:
        return json.load(resp)["choices"][0]["message"]["content"]


def run_tool(name, args):
    """工具执行：注意每个工具都返回「对模型有用」的结果字符串，而非抛异常。"""
    try:
        if name == "read_file":
            with open(args["path"], encoding="utf-8") as f:
                return f.read()[:4000]  # 截断保护：防止撑爆上下文
        if name == "write_file":
            with open(args["path"], "w", encoding="utf-8") as f:
                f.write(args["content"])
            return f"已写入 {args['path']}（{len(args['content'])} 字符）"
        if name == "run_tests":
            r = subprocess.run([sys.executable, "-m", "pytest", "-q"],
                               capture_output=True, text=True, timeout=120)
            return (r.stdout + r.stderr)[-2000:]  # 只留尾部：失败摘要在最后
        return f"未知工具: {name}。可用工具见系统提示。"
    except Exception as e:  # 错误也要变成模型能读的反馈
        return f"工具执行失败: {type(e).__name__}: {e}"


def agent_loop(task, max_steps=12):
    messages = [{"role": "system", "content": SYSTEM},
                {"role": "user", "content": f"任务：{task}"}]
    for step in range(max_steps):
        raw = chat(messages)
        try:
            action = json.loads(raw[raw.index("{"): raw.rindex("}") + 1])
        except ValueError:
            action = {"done": raw}  # 模型没按格式来：视为给出最终回答
        if "done" in action:
            print(f"[第 {step + 1} 步] 完成：{action['done']}")
            return action["done"]
        result = run_tool(action.get("tool"), action.get("args", {}))
        print(f"[第 {step + 1} 步] {action.get('tool')}({action.get('args', {})}) → {result[:80]}...")
        messages.append({"role": "assistant", "content": raw})
        messages.append({"role": "user", "content": f"工具返回：\n{result}"})
    return "达到步数上限，任务未完成。"


if __name__ == "__main__":
    agent_loop(sys.argv[1] if len(sys.argv) > 1 else "列出当前目录文件并总结这个项目是做什么的")
