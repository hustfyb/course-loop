# Agent 参考实现与开源 Agent 导读（W2/W4 教学素材）

## minimal_agent.py：60 行的完整 Agent

W2 课堂演示「Agent 没那么神秘，就是一个循环」用；W4 实验中作为学生改造开源 Agent 前的对照基线。
需要任一 OpenAI 兼容端点（环境变量 `KBQA_API_KEY` 等，默认 Kimi 开放平台）。

```
python minimal_agent.py "修复 sample_project 里失败的测试"
```

预期行为：Agent 自主完成 读测试 → 读 shop.py → 修 bug → run_tests 验证 的多步闭环。
sample_project 内置 2 个失败测试（discount 多除了 10；clamp 下界返回错值）。

## 与构成公式的逐行对照（W4 讲授提纲）

| 构成 | 代码位置 | 课堂讲点 |
|---|---|---|
| 大模型 | `chat()` | system prompt 是「出厂设定」 |
| 工具 | `TOOLS` + `run_tool()` | description 写「何时调用」；错误转成模型能读的反馈；输出截断保护上下文 |
| 记忆 | `messages` | 全部上下文都在一个列表里——这就是「记忆」的最小形态 |
| 控制循环 | `agent_loop()` | 行动 → 观察 → 再行动，直到 done 或步数上限 |

## Pi / DeepSeek Harness 导读指引（课前提取标注版）

> 不在素材包中附带第三方源码（许可证与版本漂移风险），教师按以下指引课前 15 分钟提取：

**Pi（`earendil-works/pi`，MIT）**
1. 锁定版本：`git clone --depth 1`，记录 commit hash 到课件备注
2. 导读主线：`packages/coding-agent` 下的系统提示词文件（不到 1000 tokens）→ 四个工具（read/write/edit/bash）的定义与 description → Agent Loop 主循环
3. 课堂问题锚点：「Goal 模式对应哪几行代码？」「工具失败信息如何反馈给模型？」

**DeepSeek Harness（MIT，v0.1+）**
1. 锁定版本同上；Cordis 插件系统是其与 Pi 的最大差异
2. 导读主线：模型适配器插件 → 工具注册表 → Agent 循环插件 → Trajectory 日志
3. 对照讨论：Pi「极简内核 + 扩展」vs Harness「一切皆插件」——同一种可拆解哲学的两种实现

## 常见课堂故障

- 模型不按 JSON 格式回复 → `agent_loop` 会当作最终回答退出；这正是讲「结构化输出约束」的现场素材
- API 不可用 → 降级为「代码导读 + 教师录屏」，循环逻辑不受影响
