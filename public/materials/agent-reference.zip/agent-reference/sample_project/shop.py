# -*- coding: utf-8 -*-
"""带 2 个失败测试的演示项目：W4 实验中 Agent 需要自主完成
「运行测试 → 读失败 → 改代码 → 再运行验证」的闭环。"""


def discount_price(price, discount):
    """计算折扣价。discount 为 0–1 的小数（如 0.8 表示八折）。"""
    return price * discount / 10  # BUG：多除了 10


def clamp(value, lo, hi):
    """把 value 限制在 [lo, hi] 区间。"""
    if value < lo:
        return value  # BUG：应返回 lo
    if value > hi:
        return hi
    return value
