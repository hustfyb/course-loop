# -*- coding: utf-8 -*-
from shop import discount_price, clamp


def test_discount():
    assert discount_price(100, 0.8) == 80


def test_discount_zero():
    assert discount_price(100, 0) == 0


def test_clamp_low():
    assert clamp(-5, 0, 10) == 0


def test_clamp_normal():
    assert clamp(5, 0, 10) == 5
